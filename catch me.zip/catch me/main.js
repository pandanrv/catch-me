import {init} from "./controller.js";

init();

