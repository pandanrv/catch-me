import * as controller from "./controller.js"
import * as view from "./view.js"

export var arr = null;
export var top5 = [];

export function highScores(){
  var settings = {
    url: "https://code-ec5215.appdrag.site/api/highsscores/getTop5",
    data: {
        AD_PageNbr : 1,
        AD_PageSize : 500
    },
    method: "POST",
    async: true,
    crossDomain: true,
    processData: true
};
$.ajax(settings).done(function (response) {
    arr = response.Table;
    top5 = arr.splice(0,5)
    trier(top5);
  });
}
export function trier(top5){
  top5.forEach(element => {
    var id = element.id;
    var player = element.tagname;
    var score = element.score;
    var date = element.date;
    view.affTop5(player, score, date, id)
  });
}

export function timer(){
  var countdown = setInterval(function(){
    controller.game.time.val--;
      view.affiche1();
      if (controller.game.time.val === 0) {
        clearInterval(countdown)
          view.endGame();
      }
    }, 1000);
    }

export function ajouter(finalPlayer, finalScore, dateText){
    var settings = {
      "url": "https://code-ec5215.appdrag.site/api/addplayer/addplayer",
      "data": {
        "tagname" : finalPlayer,
        "score" : finalScore,
        "date" : dateText
      },
      "method": "POST",
      "async": true,
      "crossDomain": true,
      "processData": true
    };
    $.ajax(settings).done(function (response) {
    view.refresh();
    });
  }    