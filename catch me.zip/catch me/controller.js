import * as model from "./model.js"
import * as view from "./view.js"

export function init(){
  view.affiche1();
  model.highScores();
}

export const game = {
    score: {val: 0, DOM: document.getElementById("score")},
    toLevel: {val: 10, DOM: document.getElementById("ptlevel")},
    level: {val: 1, DOM: document.getElementById("level")},
    missedClicks: {val: 0, DOM: document.getElementById("missed")},
    time: {val: 60, DOM: document.getElementById("countdown")},
    speed: {val: 1},
    toEscape: {val: 1000},
    newUser: {val: null},
    rotation: {val: 300},
  }

export var top = document.getElementById("high")
export var start = document.getElementById("catchme");
start.addEventListener("click", startGame);
export var countdown = document.getElementById("countdown");
export var toy = document.getElementById("toy");

export function startGame(){
  start.removeEventListener("click", startGame)
  model.timer();
  view.changeDiv();
  var restart = document.getElementById("restart");
  restart.addEventListener("click", view.refresh);
  view.rotation();
  toy.addEventListener("click", goodClic, { capture: false});
  toy.addEventListener("click", view.changePos);
  // toy.addEventListener("mouseover", view.stand);
  middle.addEventListener("click", wrongClic);
  }
  
export function goodClic(e){
    game.score.val += 10*game.level.val;
    game.toLevel.val -= 1;
    view.affiche1();
    if(game.toLevel.val == 0){
        nextLevel()
        reset()
      };
      if (game.level.val > 5) {
          view.endGame()
        }
        e.stopPropagation();
      } 
export function wrongClic(e){
  game.score.val -= 1*game.level.val;
  game.missedClicks.val += 1*game.level.val;
  view.affiche1();
} 
export function nextLevel(){
  game.toLevel.val = 10;
  game.level.val += 1;
  game.toEscape.val -= 50;
  game.rotation.val -= 250;
}                               
export function reset(){
  game.time.val += 10;
  view.affiche1();
}
export function dataplayer(finalPlayer, finalScore, dateText){
  var myDate = new Date();
  var theDay = myDate.getDate();
  var theMonth = myDate.getMonth()+1;
  var theYear = myDate.getFullYear();
  var dateText = theYear + "-" + theMonth + "-" + theDay;
  model.ajouter(finalPlayer, finalScore, dateText);
}