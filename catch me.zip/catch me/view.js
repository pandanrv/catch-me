import * as model from "./model.js";
import * as controller from "./controller.js"

export function affiche1(){
    controller.game.score.DOM.innerHTML = "SCORE : " + controller.game.score.val;
    controller.game.toLevel.DOM.innerHTML = "PTS TO NEXT LEVEL : " + controller.game.toLevel.val;
    controller.game.missedClicks.DOM.innerHTML = "MISSED CLICK:" + controller.game.missedClicks.val;
    controller.game.level.DOM.innerHTML = "LEVEL : " + controller.game.level.val; 
    controller.game.time.DOM.innerHTML = "COUNTDOWN :" + controller.game.time.val;
}
export function affTop5(player, score, date, id){
    controller.top.innerHTML +=
    `<div id="playerTop">
        <p onmouseover="document.getElementById('dateTop${id}').style.display='block'" onmouseout="document.getElementById('dateTop${id}').style.display='none'">${player} ${score}</p>
        <p id="dateTop${id}" style="display:none;color:greenyellow">${date}</p>
    </div>`
}
export function changeDiv(){
    controller.start.innerHTML = `<div id="restart">restart</div>`
}
export function refresh(){
    window.location.reload();                               
  }  
export function rotation(){
    var rotation = controller.game.rotation.val
    controller.toy.style.animation = "rotate 2s infinite linear"; 
}
export function changePos(){
    toy.style.top = Math.trunc(Math.random() * 500 - 15) + "px";
    toy.style.left = Math.trunc(Math.random() * 800 - 15) + "px";
    console.log(controller.game.rotation.val);
}
// export function stand() {
//     setTimeout(function(){
//     controller.toy.style.top = Math.trunc(Math.random() * 500 - 15) + "px";
//     controller.toy.style.left = Math.trunc(Math.random() * 800 - 15) + "px";
// }, controller.game.toEscape.val);
//     console.log("stand",controller.game.toEscape.val );
//   }
export function endGame(){
    var finalScore = controller.game.score.val
    var finalPlayer = prompt("enter your tagname your score is : " + finalScore)
    controller.game.newUser.val = finalPlayer;
    controller.dataplayer(finalPlayer, finalScore)
  }